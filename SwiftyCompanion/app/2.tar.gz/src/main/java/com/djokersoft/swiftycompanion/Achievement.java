package com.djokersoft.swiftycompanion;

import android.graphics.Color;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class Achievement implements Parcelable {
    private int id;
    private String name;
    private String description;
    private String tier;
    private String kind;
    private boolean visible;
    private String image;

    @SerializedName("nbr_of_success")
    private Integer nbrOfSuccess;

    @SerializedName("users_url")
    private String usersUrl;


    public Achievement() {
    }

    protected Achievement(Parcel in) {
        id = in.readInt();
        name = in.readString();
        description = in.readString();
        tier = in.readString();
        kind = in.readString();
        visible = in.readByte() != 0;
        image = in.readString();
        if (in.readByte() == 0) {
            nbrOfSuccess = null;
        } else {
            nbrOfSuccess = in.readInt();
        }
        usersUrl = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(tier);
        dest.writeString(kind);
        dest.writeByte((byte) (visible ? 1 : 0));
        dest.writeString(image);
        if (nbrOfSuccess == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(nbrOfSuccess);
        }
        dest.writeString(usersUrl);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Achievement> CREATOR = new Creator<Achievement>() {
        @Override
        public Achievement createFromParcel(Parcel in) {
            return new Achievement(in);
        }

        @Override
        public Achievement[] newArray(int size) {
            return new Achievement[size];
        }
    };

    // Getters e setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getNbrOfSuccess() {
        return nbrOfSuccess;
    }

    public void setNbrOfSuccess(Integer nbrOfSuccess) {
        this.nbrOfSuccess = nbrOfSuccess;
    }

    public String getUsersUrl() {
        return usersUrl;
    }

    public void setUsersUrl(String usersUrl) {
        this.usersUrl = usersUrl;
    }


    public String getFullImageUrl() {
        if (image != null && !image.isEmpty()) {
            String path = image.startsWith("/") ? image.substring(1) : image;


            return "https://intra.42.fr/" + path;
        }
        //return "https://cdn.intra.42.fr/achievement/image/55/SCO003.svg";
        return null;
    }
}