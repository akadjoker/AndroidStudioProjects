package com.djokersoft.swiftycompanion;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ProfilePagerAdapter extends FragmentStateAdapter {
    private final User user;

    public ProfilePagerAdapter(Fragment fragment, User user) {
        super(fragment);
        this.user = user;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return ProjectsFragment.newInstance(
                        user.getProjects(),
                        user.getCompletedProjects(),
                        user.getFailedProjects()
                );
            case 1:
                return SkillsFragment.newInstance(user.getSkills());
            case 2:
                return AchievementsFragment.newInstance(user.getAchievements());
            default:
                return new Fragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3; // Projects, Skills, Achievements
    }
}