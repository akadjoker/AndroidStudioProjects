package com.djokersoft.swiftycompanion;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.util.Log;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.djokersoft.swiftycompanion.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private boolean isAuthenticating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = NavHostFragment.findNavController( getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);


        ensureAuthentication();
    }

    public void ensureAuthentication() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Connecting to 42 API...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        ApiService.ensureValidToken(this, new ApiService.ApiCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                progressDialog.dismiss();
                isAuthenticating = false;

            }

            @Override
            public void onError(String errorMessage) {
                progressDialog.dismiss();
                isAuthenticating = false;
                showOfflineErrorFragment(errorMessage);
            }
        });
    }

    public boolean checkAuthentication() {
        return isAuthenticating;
    }

    private void showOfflineErrorFragment(String errorMessage) {
        Bundle bundle = new Bundle();
        bundle.putString("error_message", errorMessage);

        NavController navController = NavHostFragment.findNavController(
                getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));

        // Verificar se já estamos no fragmento de erro
        if (navController.getCurrentDestination().getId() != R.id.offlineErrorFragment) {
            // Navegar para o fragmento de erro offline
            navController.navigate(R.id.action_global_offlineErrorFragment, bundle);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}


/*
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "djokersoft";
    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private TokenManager tokenManager;
    private boolean isAuthenticating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);



        tokenManager = TokenManager.getInstance(this);


        checkAuthentication();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);


        handleOAuthResponse();
    }

    @Override
    protected void onResume() {
        super.onResume();

        handleOAuthResponse();

        isAuthenticating = false;
    }

    private void handleOAuthResponse() {
        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            Uri uri = intent.getData();
            if (uri.toString().startsWith(Config.REDIRECT_URI)) {
                String code = uri.getQueryParameter("code");
                if (code != null) {

                    setIntent(new Intent());

                    exchangeCodeForToken(code);

                    NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));
                    appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
                    NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
                } else if (uri.getQueryParameter("error") != null) {

                    Toast.makeText(this, "Authentication error: " + uri.getQueryParameter("error"), Toast.LENGTH_LONG).show();


                    showOfflineErrorFragment(uri.getQueryParameter("error"));

                    NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.action_global_offlineErrorFragment));
                    appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
                    NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
                }
            }
        }
    }

    public void checkAuthentication() {
        if (!tokenManager.hasTokens())
        {
            startOAuthFlow();
            return;
        }


        ApiService.validateToken(this, new ApiService.ApiCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean isValid) {
                if (!isValid) {

                    startOAuthFlow();
                }

            }

            @Override
            public void onError(String errorMessage) {

                showOfflineErrorFragment(errorMessage);
            }
        });
    }

    private void startOAuthFlow() {
        if (isAuthenticating) return;
        isAuthenticating = true;


        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Connecting to 42 API...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        Uri authUri = Uri.parse(Config.AUTH_URL)
                .buildUpon()
                .appendQueryParameter("client_id", Config.CLIENT_ID)
                .appendQueryParameter("redirect_uri", Config.REDIRECT_URI)
                .appendQueryParameter("response_type", "code")
                .appendQueryParameter("scope", "public")
                .build();

        Log.d(TAG,"utl:"+authUri.toString());

        new Handler().postDelayed(() -> {

            progressDialog.dismiss();


            Uri authUri = Uri.parse(Config.AUTH_URL)
                    .buildUpon()
                    .appendQueryParameter("client_id", Config.CLIENT_ID)
                    .appendQueryParameter("redirect_uri", Config.REDIRECT_URI)
                    .appendQueryParameter("response_type", "code")
                    .appendQueryParameter("scope", "public")
                    .build();


            Intent intent = new Intent(Intent.ACTION_VIEW, authUri);
            startActivity(intent);
        }, 500);
    }

    private void exchangeCodeForToken(String code) {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Completing authentication...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new Thread(() -> {
            try {
                OkHttpClient client = new OkHttpClient();

                FormBody formBody = new FormBody.Builder()
                        .add("grant_type", "authorization_code")
                        .add("client_id", Config.CLIENT_ID)
                        .add("client_secret", Config.CLIENT_SECRET)
                        .add("code", code)
                        .add("redirect_uri", Config.REDIRECT_URI)
                        .build();

                Request request = new Request.Builder()
                        .url(Config.TOKEN_URL)
                        .post(formBody)
                        .build();

                Response response = client.newCall(request).execute();

                if (!response.isSuccessful())
                {
                    throw new IOException("Unexpected code " + response);
                }

                String responseBody = response.body().string();

                JSONObject jsonObject = new JSONObject(responseBody);
                String accessToken = jsonObject.getString("access_token");
                String refreshToken = jsonObject.getString("refresh_token");


                tokenManager.storeTokens(accessToken, refreshToken);

                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Authentication successful", Toast.LENGTH_SHORT).show();


                    NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));
                    if (navController.getCurrentDestination().getId() == R.id.offlineErrorFragment) {
                        navController.navigate(R.id.action_offlineErrorFragment_to_FirstFragment);
                    }
                });

            } catch (Exception e) {
               Log.e(TAG, "Error during authentication", e);
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Authentication error: " + e.getMessage(), Toast.LENGTH_LONG).show();


                    showOfflineErrorFragment(e.getMessage());
                });
            }
        }).start();
    }

    private void showOfflineErrorFragment(String errorMessage) {
        Bundle bundle = new Bundle();
        bundle.putString("error_message", errorMessage);

        NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));


        if (navController.getCurrentDestination().getId() != R.id.offlineErrorFragment) {

            navController.navigate(R.id.action_global_offlineErrorFragment, bundle);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = NavHostFragment.findNavController(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main));
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}


 */