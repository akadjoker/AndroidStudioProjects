package com.djokersoft.swiftycompanion;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.djokersoft.swiftycompanion.databinding.FragmentSecondBinding;

import java.util.List;
public class SecondFragment extends Fragment {

    private static final String TAG = "djokersoft";
    private FragmentSecondBinding binding;
    private User user;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            user = getArguments().getParcelable("user");
            if (user != null) {
                Log.d("SecondFragment", "Received user: " + user.getLogin() + " with level: " + user.getLevel());
                displayUserInfo();
            } else {
                showError("No user data received");
            }
        } else {
            showError("No arguments received");
        }
    }

    private void displayUserInfo() {
        try {
            // Definir título da action bar
            if (getActivity() != null) {
                getActivity().setTitle(user.getLogin());
            }

            // Carregar imagem de perfil
            if (getContext() != null) {
                Glide.with(getContext())
                        .load(user.getImageUrl())
                        .placeholder(R.drawable.profile_placeholder)
                        .error(R.drawable.profile_error)
                        .circleCrop()
                        .into(binding.imageViewProfile);
            }

            // Exibir informações básicas
            binding.textViewLogin.setText(user.getLogin());
            binding.textViewEmail.setText(user.getEmail());
            binding.textViewLocation.setText(user.getLocation());
            binding.textViewWallet.setText("Wallet: " + user.getWallet());

            // Exibir nível
            int levelInt = user.getLevelInteger();
            int percentage = user.getLevelPercentage();
            binding.textViewLevel.setText(String.format("Level %d - %d%%", levelInt, percentage));
            binding.progressBarLevel.setProgress(percentage);

            // Configurar RecyclerViews
            setupSkillsRecyclerView();

            // Se não houver projetos, exibir mensagem
            if (user.getProjects().isEmpty()) {
                binding.textViewNoProjects.setVisibility(View.VISIBLE);
                binding.recyclerViewProjects.setVisibility(View.GONE);
            } else {
                binding.textViewNoProjects.setVisibility(View.GONE);
                binding.recyclerViewProjects.setVisibility(View.VISIBLE);
                setupProjectsRecyclerView();
            }

            // Exibir estatísticas de projetos
            binding.textViewCompletedProjects.setText(String.valueOf(user.getCompletedProjects()));
            binding.textViewFailedProjects.setText(String.valueOf(user.getFailedProjects()));

        } catch (Exception e) {
            Log.e("SecondFragment", "Error displaying user info", e);
            showError("Error displaying user information: " + e.getMessage());
        }
    }

    private void setupSkillsRecyclerView() {
        if (user.getSkills() == null || user.getSkills().isEmpty()) {
            binding.textViewNoSkills.setVisibility(View.VISIBLE);
            binding.recyclerViewSkills.setVisibility(View.GONE);
            return;
        }

        binding.textViewNoSkills.setVisibility(View.GONE);
        binding.recyclerViewSkills.setVisibility(View.VISIBLE);

        SkillsAdapter adapter = new SkillsAdapter(user.getSkills());
        binding.recyclerViewSkills.setAdapter(adapter);
        binding.recyclerViewSkills.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Adiciona um divisor entre os itens
        binding.recyclerViewSkills.addItemDecoration(
                new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL));
    }

    private void setupProjectsRecyclerView() {
        ProjectsAdapter adapter = new ProjectsAdapter(user.getProjects());
        binding.recyclerViewProjects.setAdapter(adapter);
        binding.recyclerViewProjects.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Adiciona um divisor entre os itens
        binding.recyclerViewProjects.addItemDecoration(
                new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL));
    }

    private void showError(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
        Log.e(TAG, message);
        NavController navController = NavHostFragment.findNavController(this);
        navController.navigateUp();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Adapter para habilidades
    private class SkillsAdapter extends RecyclerView.Adapter<SkillsAdapter.SkillViewHolder> {
        private final List<Skill> skills;

        public SkillsAdapter(List<Skill> skills) {
            this.skills = skills;
        }

        @NonNull
        @Override
        public SkillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_skill, parent, false);
            return new SkillViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull SkillViewHolder holder, int position) {
            Skill skill = skills.get(position);
            holder.bind(skill);
        }

        @Override
        public int getItemCount() {
            return skills.size();
        }

        class SkillViewHolder extends RecyclerView.ViewHolder {
            private final TextView textViewSkillName;
            private final TextView textViewSkillLevel;
            private final ProgressBar progressBarSkill;

            public SkillViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewSkillName = itemView.findViewById(R.id.textViewSkillName);
                textViewSkillLevel = itemView.findViewById(R.id.textViewSkillLevel);
                progressBarSkill = itemView.findViewById(R.id.progressBarSkill);
            }

            public void bind(Skill skill) {
                textViewSkillName.setText(skill.getName());
                textViewSkillLevel.setText(skill.getLevelDisplay());
                progressBarSkill.setProgress(skill.getLevelPercentage());
            }
        }
    }

    // Adapter para projetos
    private class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ProjectViewHolder> {
        private final List<Project> projects;

        public ProjectsAdapter(List<Project> projects) {
            this.projects = projects;
        }

        @NonNull
        @Override
        public ProjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_project, parent, false);
            return new ProjectViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ProjectViewHolder holder, int position) {
            Project project = projects.get(position);
            holder.bind(project);
        }

        @Override
        public int getItemCount() {
            return projects.size();
        }

        class ProjectViewHolder extends RecyclerView.ViewHolder {
            private final TextView textViewProjectName;
            private final TextView textViewProjectStatus;
            private final TextView textViewProjectMark;

            public ProjectViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewProjectName = itemView.findViewById(R.id.textViewProjectName);
                textViewProjectStatus = itemView.findViewById(R.id.textViewProjectStatus);
                textViewProjectMark = itemView.findViewById(R.id.textViewProjectMark);
            }

            public void bind(Project project) {
                textViewProjectName.setText(project.getName());
                textViewProjectStatus.setText(project.getStatusDisplay());
                textViewProjectMark.setText(project.getMarkDisplay());

                // Definir cor com base no status
                textViewProjectStatus.setTextColor(project.getStatusColor());
            }
        }
    }
}