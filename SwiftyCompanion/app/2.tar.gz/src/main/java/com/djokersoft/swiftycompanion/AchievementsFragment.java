package com.djokersoft.swiftycompanion;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.djokersoft.swiftycompanion.databinding.FragmentAchievementsBinding;
import com.djokersoft.swiftycompanion.databinding.FragmentProjectsBinding;
import com.djokersoft.swiftycompanion.databinding.FragmentSecondBinding;
import com.djokersoft.swiftycompanion.databinding.FragmentSkillsBinding;

import java.util.ArrayList;
import java.util.List;
public class AchievementsFragment extends Fragment {
    private FragmentAchievementsBinding binding;
    private List<Achievement> achievements;

    public static AchievementsFragment newInstance(List<Achievement> achievements) {
        AchievementsFragment fragment = new AchievementsFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList("achievements", new ArrayList<>(achievements));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAchievementsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getArguments() != null) {
            achievements = getArguments().getParcelableArrayList("achievements");
            setupAchievementsView();
        }
    }

    private void setupAchievementsView() {
        if (achievements == null || achievements.isEmpty()) {
            binding.textViewNoAchievements.setVisibility(View.VISIBLE);
            binding.recyclerViewAchievements.setVisibility(View.GONE);
            return;
        }

        binding.textViewNoAchievements.setVisibility(View.GONE);
        binding.recyclerViewAchievements.setVisibility(View.VISIBLE);

        AchievementsAdapter adapter = new AchievementsAdapter(achievements);
        binding.recyclerViewAchievements.setAdapter(adapter);
        binding.recyclerViewAchievements.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerViewAchievements.addItemDecoration(
                new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}