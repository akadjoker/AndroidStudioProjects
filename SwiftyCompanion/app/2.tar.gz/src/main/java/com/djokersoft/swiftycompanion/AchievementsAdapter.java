package com.djokersoft.swiftycompanion;


import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;

import java.util.List;
public class AchievementsAdapter extends RecyclerView.Adapter<AchievementsAdapter.AchievementViewHolder> {
    private final List<Achievement> achievements;
    private final RequestOptions glideOptions;
    private static final String TAG = "djokersoft";

    public AchievementsAdapter(List<Achievement> achievements) {
        this.achievements = achievements;

        // Configurar opções do Glide para todas as imagens
        this.glideOptions = new RequestOptions()
                .placeholder(R.drawable.ic_achievement)
                .error(R.drawable.ic_achievement)
                .diskCacheStrategy(DiskCacheStrategy.ALL) // Cache em disco
                .centerCrop();
    }

    @NonNull
    @Override
    public AchievementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_achievement, parent, false);
        return new AchievementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AchievementViewHolder holder, int position) {
        Achievement achievement = achievements.get(position);
        holder.bind(achievement, glideOptions);
    }

    @Override
    public int getItemCount() {
        return achievements.size();
    }

    static class AchievementViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imageViewAchievement;
        private final TextView textViewAchievementName;
        private final ProgressBar progressBarImage;

        public AchievementViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewAchievement = itemView.findViewById(R.id.imageViewAchievement);
            textViewAchievementName = itemView.findViewById(R.id.textViewAchievementName);
            progressBarImage = itemView.findViewById(R.id.progressBarImage);
        }

        public void bind(Achievement achievement, RequestOptions glideOptions) {
            textViewAchievementName.setText(achievement.getName());

            // Configurar um tooltip com a descrição
            itemView.setTooltipText(achievement.getDescription());

            // Configurar o clique para mostrar a descrição
            itemView.setOnClickListener(v -> {
                Toast.makeText(itemView.getContext(),
                        achievement.getDescription(),
                        Toast.LENGTH_LONG).show();
            });

            // Mostrar indicador de progresso
            progressBarImage.setVisibility(View.VISIBLE);
            imageViewAchievement.setVisibility(View.INVISIBLE);

            // Carregar ícone
            String imageUrl = achievement.getFullImageUrl();
            if (imageUrl != null) {


                Glide.with(itemView.getContext())
                        .load(imageUrl)
                        .apply(glideOptions)
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource)
                            {
                                Log.e(TAG, "SVG loading failed:"+imageUrl, e);
                                progressBarImage.setVisibility(View.GONE);
                                imageViewAchievement.setVisibility(View.VISIBLE);
                                return false;
                            }



                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                progressBarImage.setVisibility(View.GONE);
                                imageViewAchievement.setVisibility(View.VISIBLE);
                                Log.d(TAG, "SVG loaded successfully"+imageUrl);
                                return false;
                            }
                        })
                        .into(imageViewAchievement);
            } else {
                // Colocar ícone padrão
                imageViewAchievement.setImageResource(R.drawable.ic_achievement);
                progressBarImage.setVisibility(View.GONE);
                imageViewAchievement.setVisibility(View.VISIBLE);
            }
        }
    }
}